﻿using RoR2;
using System.Collections.Generic;

namespace $safeprojectname$.Utils
{

    //this class is purely for handling lists of items, just to make it a little easier and clear to introduce.
    //Each list stores the things we create so they can be easily added later
    public static class ListHandlers
    {

        public static List<ItemDef> ItemDefList { get; set; } = new List<ItemDef>();

    }

}
