﻿using BepInEx.Configuration;
using R2API;
using RoR2;
using $safeprojectname$.Base_Classes;
using static $safeprojectname$.Utils.ItemHelper;

namespace $safeprojectname$.Template_Plates
{
    class Item_Template : ItemBase
    {
        public override string ItemName => throw new NotImplementedException();

        public override string ItemLangTokenName => throw new NotImplementedException();

        public override string ItemPickupDesc => throw new NotImplementedException();

        public override string ItemFullDescription => throw new NotImplementedException();

        public override string ItemLore => throw new NotImplementedException();

        public override ItemTier Tier => throw new NotImplementedException();

        public override string ItemModelPath => throw new NotImplementedException();

        public override string ItemIconPath => throw new NotImplementedException();

        public override ItemDisplayRuleDict CreateItemDisplayRules()
        {
            throw new NotImplementedException();
        }

        public override void Hooks()
        {
            throw new NotImplementedException();
        }

        public override void Init(ConfigFile config)
        {
            throw new NotImplementedException();
        }
    }
}
